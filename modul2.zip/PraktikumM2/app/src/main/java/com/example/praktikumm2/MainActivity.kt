package com.example.praktikumm2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    private lateinit var teknikPindah:TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        teknikPindah = findViewById(R.id.ft)
    }

    fun fisiblaunch(view: android.view.View) {}
    fun fpenlaunch(view: android.view.View) {}
    fun fkislaunch(view: android.view.View) {}
    fun hukumlaunch(view: android.view.View) {}
    fun feblaunch(view: android.view.View) {}
    fun pertanianlaunch(view: android.view.View) {}
    fun tekniklaunch(teknik: android.view.View) {
        val intent = Intent(this, fteknik::class.java)
        startActivity(intent)
    }
}
