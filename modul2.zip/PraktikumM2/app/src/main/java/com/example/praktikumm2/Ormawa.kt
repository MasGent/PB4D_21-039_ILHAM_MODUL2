package com.example.praktikumm2

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Ormawa(
    val imageOrmawa:Int,
    val namaOrmawa: String
) : Parcelable
