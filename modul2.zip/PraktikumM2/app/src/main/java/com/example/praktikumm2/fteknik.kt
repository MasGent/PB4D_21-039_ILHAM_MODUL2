package com.example.praktikumm2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class fteknik : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fteknik)

        val ormawaList = listOf<Ormawa>(
            Ormawa(
                R.drawable.himasi,
                "HIMASI"
            ),
            Ormawa(
                R.drawable.himatif,
                "HIMATIF"
            ),
            Ormawa(
                R.drawable.hmti,
                "HMTI"
            ),
            Ormawa(
                R.drawable.himameka,
                "HIMAMEKA"
            ),
            Ormawa(
                R.drawable.hmm,
                "HMM"
            ),
            Ormawa(
                R.drawable.himatro,
                "HIMATRO"
            )
        )
        val recyclerView =findViewById<RecyclerView>(R.id.rv_ormawa)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.setHasFixedSize(true)
        recyclerView.adapter = ormawaAdapter(this, ormawaList){
        }

    }
}