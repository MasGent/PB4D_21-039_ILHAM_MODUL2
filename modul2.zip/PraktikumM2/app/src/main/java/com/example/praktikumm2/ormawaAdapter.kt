package com.example.praktikumm2

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ormawaAdapter (private val context: Context, private val ormawa: List<Ormawa>, val listerner : (Ormawa)-> Unit)
    : RecyclerView.Adapter<ormawaAdapter.ormawaViewHolder>(){
    class ormawaViewHolder(view: View):RecyclerView.ViewHolder(view) {

        val imageOrmawa=view.findViewById<ImageView>(R.id.gambar)
        val namaOrmawa=view.findViewById<TextView>(R.id.nama)

        fun bindView(ormawa: Ormawa, listerner: (Ormawa) -> Unit){
            imageOrmawa.setImageResource(ormawa.imageOrmawa)
            namaOrmawa.text = ormawa.namaOrmawa
        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ormawaViewHolder {
        return ormawaViewHolder(
            LayoutInflater.from(context).inflate(R.layout.item_list, parent, false)
        )
    }

    override fun onBindViewHolder(holder: ormawaViewHolder, position: Int) {
        holder.bindView(ormawa[position], listerner)
    }

    override fun getItemCount(): Int = ormawa.size
    }